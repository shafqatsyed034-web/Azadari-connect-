package com.azadariconnect.app

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun LiveKaflaScreen(
    kaflaName: String = "Karwan-e-Hussaini",
    route: String = "Tando Muhammad Khan → Hyderabad → Sehwan → Sukkur → Karbala"
) {
    var isLive by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
    ) {
        // Map placeholder: replace with Google Maps in production.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(330.dp)
                .background(Color(0xFFE1E7EA)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Map,
                    contentDescription = "Map",
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text("LIVE ROUTE MAP", fontWeight = FontWeight.Bold)
                Text("Google Maps integration goes here")
                Spacer(Modifier.height(18.dp))
                AssistChip(
                    onClick = {},
                    label = { Text(if (isLive) "🔴 LIVE" else "OFFLINE") }
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(kaflaName, fontSize = 24.sp, fontWeight = FontWeight.Bold)

            Card(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📍 Current Location", fontWeight = FontWeight.Bold)
                    Text("Location will appear here when the organizer starts live tracking.")

                    HorizontalDivider()

                    Text("➡️ Next Stop", fontWeight = FontWeight.Bold)
                    Text("Sehwan")

                    Text("⏱️ Estimated Arrival", fontWeight = FontWeight.Bold)
                    Text("2 hours 15 minutes")

                    Text("🗺️ Route", fontWeight = FontWeight.Bold)
                    Text(route)
                }
            }

            Button(
                onClick = { isLive = !isLive },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isLive) Color(0xFFB71C1C) else Color(0xFF176B4D)
                )
            ) {
                Icon(
                    if (isLive) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null
                )
                Spacer(Modifier.width(8.dp))
                Text(if (isLive) "STOP LIVE LOCATION" else "START LIVE LOCATION")
            }

            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Call, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Contact Organizer")
            }
        }
    }
}
