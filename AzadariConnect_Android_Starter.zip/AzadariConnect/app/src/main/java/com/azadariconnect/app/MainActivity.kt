package com.azadariconnect.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Majlis(
    val title: String,
    val city: String,
    val venue: String,
    val date: String,
    val time: String
)

data class Kafla(
    val title: String,
    val route: String,
    val status: String
)

private val Red = Color(0xFFB71C1C)
private val Gold = Color(0xFFFFC107)
private val Navy = Color(0xFF071923)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AzadariConnectApp() }
    }
}

@Composable
fun AzadariConnectApp() {
    var selected by remember { mutableIntStateOf(0) }

    val tabs = listOf(
        "Home" to Icons.Default.Home,
        "Majalis" to Icons.Default.Event,
        "Kaflay" to Icons.Default.DirectionsBus,
        "Donate" to Icons.Default.Favorite
    )

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Red,
            secondary = Gold,
            surface = Color.White,
            background = Color(0xFFF5F5F5)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Azadari Connect", fontWeight = FontWeight.Bold)
                            Text("Majalis • Kaflay • Live Routes", fontSize = 11.sp)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Navy,
                        titleContentColor = Color.White
                    ),
                    actions = {
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.Search, "Search", tint = Color.White)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, pair ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(pair.second, pair.first) },
                            label = { Text(pair.first) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (selected) {
                    0 -> HomeScreen(onMajlis = { selected = 1 }, onKafla = { selected = 2 }, onDonate = { selected = 3 })
                    1 -> MajalisScreen()
                    2 -> KaflayScreen()
                    3 -> DonationScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onMajlis: () -> Unit, onKafla: () -> Unit, onDonate: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Navy),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("Ya Hussain (a.s.)", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Worldwide Majalis & Kafla Network", color = Color.White)
                    Spacer(Modifier.height(16.dp))
                    Text("📍 Tando Muhammad Khan", color = Color.White)
                }
            }
        }

        item {
            Text("Quick Access", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureButton("🕌\nMajalis", Modifier.weight(1f), onMajlis)
                FeatureButton("🚌\nKaflay", Modifier.weight(1f), onKafla)
                FeatureButton("❤️\nDonate", Modifier.weight(1f), onDonate)
            }
        }

        item {
            Text("Upcoming Majalis", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        item {
            MajlisCard(
                Majlis(
                    "Majlis-e-Aza",
                    "Tando Muhammad Khan",
                    "Imambargah Hussainia",
                    "10 Sep 2026",
                    "8:00 PM"
                )
            )
        }

        item {
            Text("Live Kaflay", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        item {
            KaflaCard(
                Kafla(
                    "Karwan-e-Hussaini",
                    "TMK → Hyderabad → Sehwan → Sukkur → Karbala",
                    "LIVE"
                )
            )
        }
    }
}

@Composable
fun FeatureButton(text: String, modifier: Modifier, action: () -> Unit) {
    Card(
        modifier = modifier.clickable { action() },
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Box(Modifier.padding(12.dp).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(text, textAlign = androidx.compose.ui.text.style.TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MajalisScreen() {
    val list = listOf(
        Majlis("Majlis-e-Aza", "Tando Muhammad Khan", "Imambargah Hussainia", "10 Sep 2026", "8:00 PM"),
        Majlis("Majlis-e-Aza", "Hyderabad", "Central Imambargah", "12 Sep 2026", "9:00 PM"),
        Majlis("Majlis-e-Aza", "Karachi", "Markazi Imambargah", "15 Sep 2026", "8:30 PM")
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Upcoming Majalis", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        items(list) { MajlisCard(it) }
    }
}

@Composable
fun MajlisCard(m: Majlis) {
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(m.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("📍 ${m.venue}, ${m.city}")
            Text("📅 ${m.date}   🕒 ${m.time}")
            Spacer(Modifier.height(10.dp))
            Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                Text("View Details & Donate")
            }
        }
    }
}

@Composable
fun KaflayScreen() {
    val list = listOf(
        Kafla("Karwan-e-Hussaini", "Tando Muhammad Khan → Hyderabad → Sehwan → Sukkur → Karbala", "LIVE"),
        Kafla("Safar-e-Hussaini", "Karachi → Iran → Iraq", "UPCOMING")
    )
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Kaflay", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        items(list) { KaflaCard(it) }
    }
}

@Composable
fun KaflaCard(k: Kafla) {
    Card(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(k.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                AssistChip(onClick = {}, label = { Text(k.status) })
            }
            Spacer(Modifier.height(6.dp))
            Text("🚌 ${k.route}")
            Spacer(Modifier.height(10.dp))
            if (k.status == "LIVE") {
                Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.LocationOn, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Open Live Location")
                }
            }
        }
    }
}

@Composable
fun DonationScreen() {
    var amount by remember { mutableStateOf("1000") }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Donate", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Support a verified Majlis or Kafla.")
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Amount (PKR)") },
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("500", "1000", "2000", "5000").forEach {
                OutlinedButton(onClick = { amount = it }) { Text("Rs. $it") }
            }
        }
        Text("Payment methods will be connected in the production version.")
        Button(onClick = {}, modifier = Modifier.fillMaxWidth()) {
            Text("Continue Donation")
        }
    }
}
